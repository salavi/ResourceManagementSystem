import java.awt.Label;

import javax.swing.JFrame;
import javax.swing.JPanel;


public class Main {
	public static void main(String[] args) {
		JFrame j1 = new JFrame();
		JPanel j2 = new JPanel();
		j1.add(j2);
		j2.add(new Label("soheil"));
		
	}
	
	

}

